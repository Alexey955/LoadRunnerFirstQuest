/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 1203
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_add_cookie("SRCHD=AF=IESS4N; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUID=V=2&GUID=68DC1504E1054ACCBA0DFFF01477392F&dmnchg=1; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUSR=DOB=20181226; DOMAIN=www.bing.com");

	web_add_cookie("MUID=08D12E060D366887178922D70C476981; DOMAIN=www.bing.com");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	return 0;
}